---
title: "Rider 快捷键"
date: 2023-02-16 15:06:18
tags: ["IDE"]
categories: ["编辑器"]
---

# Rider 快捷键 #

## 位置相关 ##
切换上个选项卡 Ctrl + PageUp   
切换下个选项卡 Ctrl + PageDown   
后退 Ctrl + -   
前进 Ctrl + +   
快速设置书签 Ctrl + K, Ctrl + K   
显示书签 Ctrl + K, Ctrl + S   
设置书签 Ctrl + F11   
快速定义 Alt + F12   
转到定义 F12   

## 退出 ##
选项卡关闭 Ctrl + F4   
退出小窗口 Esc 或 Shift + Esc   

## 提示 ##
文档提示 Ctrl + K, Ctrl + I   

## 查找替换 ##   
该文件查找 Ctrl + F   
全局查找 Shift, Shift   
该文件内替换 Ctrl + H   
查找引用 Shift + F12   

## 结构 ##
折叠 Ctrl + M, Ctrl + M   
全部收起 Ctrl + M, Ctrl + A   
全部展开 Ctrl + M, Ctrl + X
格式化 Ctrl + K, Ctrl + F   
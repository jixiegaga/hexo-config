---
title: unity学习版
date: 2023-03-12 21:02:56
tags: ["unityHub"]
categories: ["我是学生"]

---

# 国际版下载方式 #
1. 打开全局代理，下载过程需要全程开启
2. 官方下载地址<https://unity.com/download#how-get-started>
3. 启动方式(切规则代理)   
   + 方式一
   ```CMD
   @echo off
   set HTTP_PROXY=http://127.0.0.1:7890
   set HTTPS_PROXY=http://127.0.0.1:7890
   start "" "D:\Unity Hub\Unity Hub.exe"
   ```   
   + 方式二
   在Clash for Window里设置代理规则，关键字unity,unityhub

---

# 学习软件 #
<https://github.com/tylearymf/UniHacker>

---
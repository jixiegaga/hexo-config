---
title: rider学习版
date: 2023-03-12 23:02:56
tags: ["rider"]
categories: ["我是学生"]

---

# 本体下载 #   
<https://www.jetbrains.com/rider/download/#section=windows>

---

# 学习信息 #   
+ 学习付费版   
bilibili:<https://www.bilibili.com/read/cv11200249>   
解压码:mpvgg   
qq:3184207379   
百度云(提取码yj9y):<https://pan.baidu.com/s/166rVZexR_-LB7Dc1czesmA>

+ 白嫖学习版   
教程:<https://www.exception.site>   
公众号:Java学习者社区(回复:idea)

---